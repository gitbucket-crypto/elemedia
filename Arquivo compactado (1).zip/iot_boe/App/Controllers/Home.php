<?php

namespace App\Controllers;

include_once('./vendor/autoload.php');


class Home implements \Core\Controller
{
    
    public function __construct()
    {
        
    }
    
    public function _call()
    {
        $this->after();
        static::indexAction();
    }
    
    
    static function indexAction()
    {
        \Core\View::renderTemplate('index');
    }
    
    public function after()
    {
        
    }
    
}



?>