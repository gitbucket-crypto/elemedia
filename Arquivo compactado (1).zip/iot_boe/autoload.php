<?php



spl_autoload_register(static function ($class)
{
    $class .='.php';
});

?>
