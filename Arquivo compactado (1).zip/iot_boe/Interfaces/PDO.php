<?php 


namespace Interfaces;

interface PDO {


    public function connect();

    static function getInstance();



}

?>