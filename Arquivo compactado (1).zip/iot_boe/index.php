<?php 

require_once('vendor/autoload.php');
require_once("Core/Config.php");

new Core\Config(0);

$router = new \Core\Router();


$router->get('/',function()
{
    $r = new Core\Handler(); 
    $r->handle($r::CALLABLE,  "App\Controllers\Home@indexAction" ,$_REQUEST);}
);


try
{
    $router->run();
}
catch(\Execption $e)
{
    print_r($e->getMessage());
}
?>