<?php 


namespace Core;


class View
{
    public function __construct()
    {
        
    }
    
    
    public static function renderTemplate($template, array $args = [], $message = null): void
    {
        if(file_exists(dirname(__DIR__)."/App/Views"."/".$template.'.blaze.php')==true)
        {
            if($message!='' | $message !=null)
            {
                $_SESSION['flask_message'] = $message;
            }
            if(!empty($args))
            {
                var_dump($args); exit;
            }
            require_once("./App/Views"."/".$template.'.blaze.php');exit;
        }
		
    }
    
}

?>