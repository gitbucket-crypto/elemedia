<?php 


namespace Core;


interface  Controller
{
    public function after();
    
    public function _call();
}

?>