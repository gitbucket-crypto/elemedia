<?php 
namespace Core;

use Config;
use Interfaces\PDO;


class Database implements PDO
{
        public function __construct()
        {

        }


        public function connect()
        {
            $this->conn  = new \PDO('pgsql:host='.strval(Config::DB_HOST).';port='.intval(Config::DB_PORT).';dbname='.strval(Config::DB_NAME).';user='.strval(Config::DB_USER).';password='.strval(Config::DB_PASSWORD));
            $this->conn ->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            return $this->conn;
        }

        public static function getInstance()
        {
            if(static::$instance == null)
            {
                static::$instance = new Database();
            }
            return static::$instance;
        }


        private $conn;

        private static $instance;
}

?>