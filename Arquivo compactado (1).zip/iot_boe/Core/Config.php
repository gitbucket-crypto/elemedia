<?php 
declare(strict_types=1);
namespace Core;


ini_set('display_errors', true);
ini_set('allow_url_open',true);
ini_set('allow_url_open',true);


date_default_timezone_set('America/Sao_Paulo');


class Config
{
    public function __construct($mode)
    {
        static::setMaintenance($mode);
        static::bootstrap();
    }
    
    
    public static function bootstrap()
    {
        if(static::getMaintenance()==1)
        {
            return require_once("./App/view/out.blaze.php"); die();
        }
        
    }
    
    
    public static function setMaintenance($is)
    {
        static::$MAINTENANCE =$is;
    }
    
    public static function getMaintenance()
    {
        return static::$MAINTENANCE;    
    }

    public static function Welcome()
    {
        $hora = date('H');
        if( $hora >= 6 && $hora <= 12 )
            echo 'Bom dia';
        else if ( $hora > 12 && $hora <=18  )
            echo 'Boa tarde';
        else
            echo 'Boa noite';
    }
    
    
    static $MAINTENANCE;
    
 	const DB_HOST		= '127.0.0.1';
	const DB_NAME		= 'iotdatabase';
	const DB_USER		= 'postgres';
	const DB_PASSWORD	= 'fast9002';
    const DB_PORT       = 5432;
    
    const ASSETS= './App/Views/';

    
    
}

?>