<?php 


function connect()
{
		$host = "127.0.0.1";
		$port = "5432";
		$dbname = "iotdatabase";
		$user= "postgres";
		$password = 'fast9002';	
		
		$conn  = new \PDO('pgsql:host='.$host.';port='.$port.';dbname='.$dbname.';user='.$user.';password='.$password);
		$conn ->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
		return $conn;
}

?>
