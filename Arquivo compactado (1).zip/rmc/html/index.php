<?php 
global $conn;

$conn  = connect();
function connect()
{
		$host = "127.0.0.1";
		$port = "5432";
		$dbname = "iotdatabase";
		$user= "postgres";
		$password = 'fast9002';	
		
		$conn  = new \PDO('pgsql:host='.$host.';port='.$port.';dbname='.$dbname.';user='.$user.';password='.$password);
		$conn ->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
		return $conn;
}

?>

<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
<table>
  <tr>
    <th>uid</th>
    <th>data</th>
    <th>datetime</th>
    <th>RMC Mac</th>
  </tr>

  <?php
  
  $stmt = $conn->query("SELECT * FROM predatasets ORDER BY abs(extract(epoch from (datetime - now()))) LIMIT 20");
  while ($row = $stmt->fetch()) {
      echo '<tr>'.'<td>'.$row['uid'].'</td>'.
                  '<td>'.$row['raw_data'].'</td>'.
                  '<td>'.$row['dateTime'].'</td>'.
                  '<td>'.$row['rmc_mac'].'</td>'.'</tr>';
  }
  
  ?>
  </table>

</body>
</html>
