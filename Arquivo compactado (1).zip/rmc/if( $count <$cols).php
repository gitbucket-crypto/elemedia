 if( $count <$cols)
                    {
                        if(intval($i)==intval(0))
                        {
                            $col1 =$arr[$i];
                            $valor1 = $arr[1+$col1].$arr[2+$col1].$arr[3+$col1]; echo $valor1;exit; //.$arr[4+$col1]; 
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '11' , $col1 , $valor1, $dateTime ] );
                            unset($stmt);
                            unset($col1); unset($valor1);
                        }
                        if(intval($i+$cols)==intval(5))
                        {
                            $v = $i+$cols;  
                            $col2 = $arr[$v];
                            $valor2 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '11' , "'".$col2."'" , "'".$valor2."'" , $dateTime ] );
                            unset($col2); unset($valor2);unset($stmt);
                        }
                        if(intval($i+$cols)==intval(10))
                        {
                            $v = $i+$cols; 
                            $col3 = $arr[$v];
                            $valor3 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '11' , "'".$col3."'" , "'".$valor3."'" , $dateTime ] );
                            unset($col3); unset($valor3); unset($stmt);
                        }
                        break;
                    }
                    $count +=1;
                }