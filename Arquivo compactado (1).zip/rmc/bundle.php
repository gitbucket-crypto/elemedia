<?php 
include_once('RMC.php');

class Bundle
{

    public function __construct()
    {
        self::$list = array();
    }


    public function push($class , $data)
    {
        array_push(self::$list, ['class'=> $class, 'data'=>$data]); 
        echo 'push';
    }


    public function processList()
    {
        if(!empty(self::$list))
        {
            for($i =0 ; $i < count(self::$list); $i++)
            {
                $this->class  = new self::$list[$i]['class'](self::$list[$i]['data']);
                unset(self::$list[$i]['class']);
                unset(self::$list[$i]['data']);
                unset($this->class);
            }
        }
        else echo "no data to process"; 
    }


    private $class;

    public static $list;

    

}

// based on original work from the PHP Laravel framework
if (!function_exists('str_contains')) {
    function str_contains($haystack, $needle) 
    {
        return $needle !== '' && mb_strpos($haystack, $needle) !== false;
    }
}


?>