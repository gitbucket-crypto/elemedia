<?php 

	include_once("database.php");


		function parseData($dataRaw)
		{
			if(empty($dataRaw) | $dataRaw== false | $dataRaw ==null )
			{
				die("No Data Came");
			}

			$conn = connect();

			setLen($dataRaw);  //pega o comprimento do data RAW
			  
			$UID =GUID(); // set o ID a ser utilizado no DB  

			$dateTime = 'NOW()';

			$SQL ="INSERT INTO predatasets (uid, raw_data, raw_bytes,datetime, rmc_ip) VALUES ( ? , ? , ? , ? , ? )";
			$stmt = $conn -> prepare($SQL);
			$stmt->execute( [$UID, strval( $dataRaw), strval($dataRaw)  , $dateTime  , 'not present'] ) or die('d');
			$stmt->execute( [$UID, strval( $dataRaw), strval($dataRaw)  , $dateTime  , 'not present'] ) or die('d');
			unset($stmt);


			$dataRaw = preg_replace('/'.FOOTER.HEADER.'/', FOOTER.'@'.HEADER , $dataRaw); //adiciona o @ onde o footer for serguido do header
			$dataArr = explode("@", $dataRaw); //modelo de data abaixo

			$dataUnsed = array();
			//Remove os headers e footers, e os quatro primeiros bytes que não são utilizaveis
			for($i=0; $i< count($dataArr); $i++)
			{

				if(intval(strlen($dataArr[$i])) > 52 )
				{
					$dataArr[$i] = removeUnsedBytes(removeHeader(removeFooter($dataArr[$i])));
				}
				else
				{
					array_push($dataUnsed,removeHeader(removeFooter($dataArr[$i])));
					unset($dataArr[$i]);
				}
			
			
			}
			//modelo de data abaixo
			/**
			 *tipo     qtde colunas    indice primeira coluna    valor vaiavel  CRC
			 * 01   |    "01       |    00     |               01 00 00 00   |  f9" 
			 */ 
			
			 var_dump($dataArr); return;
			for($i= 0; $i< count($dataArr); $i++)
			{
				$typedef= strval(substr($dataArr[$i], 0 , 2));  //pega os dois primeiros indices, testa para ver se é 
				if(false === (intval($typedef)))
				{
					//$typedef = hexdec(strval($typedef));
				}
				echo " - ".$typedef."- "; 
				
				return;
				switch($typedef)
				{
					case  DOOR_TYPE:
						$d1 = $dataArr[$i];
						//get CRC digits
						$crc = substr($d1, strlen($d1)-2, strlen($d1));
						$d1 = str_replace($crc, "", $d1);  //remover o crc
						
						$dt =utf8_str_split($d1,2);
						$vv = $dt[3].$dt[4].$dt[5].$dt[6]; //valor variavel não convertido
					 
						try
						{
							$stmt  = $conn -> prepare("INSERT INTO  parseddatasets (uid, tipo, tipo_size, tipo_qtde_params, datahora) VALUES ( ? , ? , ? , ? , ?  )");
							$stmt->execute( [$UID, strval( DOOR_TYPE), strval($dt[2]) , strval($crc) , $dateTime ] );
							unset($stmt);
	
							$stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
							$stmt->execute( [$UID, strval( DOOR_TYPE ), "'".$dt[2]."'" , "'".$vv."'" , $dateTime ] );
							unset($stmt);
						}
						catch(\Exception $err)
						{
							print_r($err); exit;
						}
						finally
						{
							unset($d1); unset($crc); unset($dt); unset($vv); 
						}
					break;	
					case WATER_TYPE: 
						$d2 = $dataArr[$i];
						 //get CRC digits
						$crc = substr($d2, strlen($d2)-2, strlen($d2)); 
						$d2 = str_replace($crc, "", $d2);  //remover o crc
	
						$dt  = utf8_str_split($d2, 2);
						$vv = $dt[3].$dt[4].$dt[5].$dt[6]; //valor variavel não convertido
						try
						{
							//$stmt  = $this->conn -> prepare("INSERT INTO  parseddatasets (uid, tipo, tipo_size, tipo_qtde_params,  rmc_ip, datahora) VALUES ( ? , ? , ? , ? , ? , ? )");
							//$stmt->execute( [$this->$UID,  WATER_TYPE , "'".$crc."'"." ".hexdec($crc) , "'".$dt[2]."'" ,"not present" , $dateTime ] );
							//unset($stmt);
	
							$stmt  = $conn -> prepare("INSERT INTO  parseddatasets (uid, tipo, tipo_size, tipo_qtde_params, datahora) VALUES ( ? , ? , ? , ? , ?  )");
							$stmt->execute( [$UID, strval(WATER_TYPE), strval($dt[2]) , strval($crc) , $dateTime ] );
							unset($stmt);

							$stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
							$stmt->execute( [$UID, WATER_TYPE , "'".$dt[2]."'" , "'".$vv."'" , $dateTime ] );
							unset($stmt);
						}
						catch(\Exception $err)
						{
							print_r($err); exit;
						}
						finally
						{
							unset($d2); unset($crc); unset($dt); unset($vv); 
						}				
					break;
					case  LIGHT_TYPE: 
						$d3 = $dataArr[$i];
						 //get CRC digits
						$crc = substr($d3, strlen($d3)-2, strlen($d3));  
	
						$d3 = trim(str_replace($crc, "", $d3));  //remover o crc   030400e30c000001e30c000002e30c000003e30c0000
						$d3 = trim(substr($d3,2, strlen($d3))); //remover o typedef  0400e30c000001e30c000002e30c000003e30c0000
	
						$cols =intval(substr($d3,0,2)) ;
	
						$d3 = trim(substr($d3,2, strlen($d3))); // remove a quantidade de colunas 00e30c000001e30c000002e30c000003e30c0000
	
						$arr = (utf8_str_split($d3,2));
	
						$valor1 = null;
						$valor2 = null;
						$valor3 = null;
						$valor4 = null;
	
						$col1 = null;
						$col2 = null;
						$col3 = null;
						$col4 = null;
	
						$count = 0;
	
				

						$stmt  = $conn -> prepare("INSERT INTO  parseddatasets (uid, tipo, tipo_size, tipo_qtde_params, datahora) VALUES ( ? , ? , ? , ? , ?  )");
						$stmt->execute( [$UID, strval( LIGHT_TYPE), strval($cols) , strval($crc) , $dateTime ] );
						unset($stmt);
	
						for($i =0 ; $i< count($arr); $i++)
						{
							if($count<$cols)
							{
								if($i==0)
								{
									$col1 = $arr[$i];
									$valor1 = $arr[1].$arr[2].$arr[3].$arr[4];
									$stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
									$stmt->execute( [$UID,  LIGHT_TYPE , "'".$col1."'" , "'".$valor1."'" , $dateTime ] );
									unset($stmt);
									unset($col1); unset($valor1);
	
								}
								if($i+$cols=5)
								{
									$v = $i+$cols;  
									$col2 = $arr[$v];
									$valor2 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
									$stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
									$stmt->execute( [$UID,  LIGHT_TYPE , "'".$col2."'" , "'".$valor2."'" , $dateTime ] );
									unset($col2); unset($valor2);unset($stmt);
								}
								if($i+$cols=10)
								{
									$v = $i+$cols; 
									$col3 = $arr[$v];
									$valor3 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
									$stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
									$stmt->execute( [$UID,  LIGHT_TYPE , "'".$col3."'" , "'".$valor3."'" , $dateTime ] );
									unset($col3); unset($valor3); unset($stmt);
								}
								if($i+$cols=15)
								{
									$v = $i+$cols; 
									$col4 = $arr[$v];
									$valor4 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
									$stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
									$stmt->execute( [$UID,  LIGHT_TYPE , "'".$col4."'" , "'".$valor4."'" , $dateTime ] );
									unset($col4); unset($valor4); unset($stmt);
								}
								break;
							}
							$count +=1;
						}
	
					break;
					case  TEMP_HUMIDITY_TYPE:  
						$d4 = $dataArr[$i];
						 //get CRC digits
						$crc = substr($d4, strlen($d4)-2, strlen($d4)); 
						print_r($d4); exit;
					break;
					case  TEMP_TYPE: //at Moment no data
					break;
					case  G_SENSOR_TYPE: 
						$d6 = $dataArr[$i];
						print_r($d6); exit;
							//get CRC digits
						$crc = substr($d6, strlen($d6)-2, strlen($d6)); 
					break;
					case  RAP_TYPE: 
						$d7 = $dataArr[$i];
						print_r($d7); exit;
							//get CRC digits
						$crc = substr($d7, strlen($d7)-2, strlen($d7));
					break;
					case  GPIO_TYPE: 
						$d8 = $dataArr[$i];
						print_r($d8); exit;
						//get CRC digits
						$crc = substr($d8, strlen($d8)-2, strlen($d8)); 
					break;
					case  RELAY_TYPE: 
						$d9 = $dataArr[$i];
						print_r($d9); exit;
						//get CRC digits
						$crc = substr($d9, strlen($d9)-2, strlen($d9));
					break;
					case  VOLTAGE_TYPE: 
						$d10 = $dataArr[$i];
						//get CRC digits
						$crc = substr($d10, strlen($d10)-2, strlen($d10)); 
					break;
					case  NOISE_TYPE:  
						$d11 = $dataArr[$i];
						//get CRC digits
						$crc = substr($d11, strlen($d11)-2, strlen($d11));
					break;
					case  SMOK_TYPE: 
						$d12 = $dataArr[$i];
						//get CRC digits
						$crc = substr($d12, strlen($d12)-2, strlen($d12)); 
					   //1254e1ad8378e601ab0b00000200000000030000000096
					    $d12 = trim(str_replace($crc, "", $d12));
						$d12 = trim(substr($d12 ,2, strlen($d12))); //remover o typedef   
						//54e1ad8378e601ab0b000002000000000300000000
						$cols =intval(substr($d12,1,2)) ;

						$arr = (utf8_str_split($d12,2));  
	
						$valor1 = null;
						$valor2 = null;
						$valor3 = null;
						$valor4 = null;
	
						$col1 = null;
						$col2 = null;
						$col3 = null;
						$col4 = null;
	
						$count = 0;

						$stmt  = $conn -> prepare("INSERT INTO  parseddatasets (uid, tipo, tipo_size, tipo_qtde_params, datahora) VALUES ( ? , ? , ? , ? , ?  )");
						$stmt->execute( [$UID, strval( SMOK_TYPE), strval($cols) , strval($crc) , $dateTime ] ) or die('stmt error line 250');
						unset($stmt);

						for($i =0 ; $i< count($arr); $i++)
						{
							if($count<$cols)
							{
								if($i==1)
								{
									$col1 = $arr[$i];
									$valor1 = $arr[1+$col1].$arr[2+$col1].$arr[3+$col1].$arr[4+$col1];
									$stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
									$stmt->execute( [$UID,  SMOK_TYPE , "'".$col1."'" , "'".$valor1."'" , $dateTime ] );
									unset($stmt);
									unset($col1); unset($valor1);
								}	
								if($i+$cols=6)
								{
									$v = $i+$cols;  
									$col2 = $arr[$v];
									$valor2 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
									$stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
									$stmt->execute( [$UID,  SMOK_TYPE , "'".$col2."'" , "'".$valor2."'" , $dateTime ] );
									unset($col2); unset($valor2);unset($stmt);
								}
								if($i+$cols=11)
								{
									$v = $i+$cols; 
									$col3 = $arr[$v];
									$valor3 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
									$stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
									$stmt->execute( [$UID,  SMOK_TYPE , "'".$col3."'" , "'".$valor3."'" , $dateTime ] );
									unset($col3); unset($valor3); unset($stmt);
								}
								if($i+$cols=16)
								{
									$v = $i+$cols; 
									$col4 = $arr[$v];
									$valor4 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
									$stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
									$stmt->execute( [$UID,  SMOK_TYPE , "'".$col4."'" , "'".$valor4."'" , $dateTime ] );
									unset($col4); unset($valor4); unset($stmt);
								}
								break;
							}
							$count +=1;
						}
						
					break;
					case  ELECTRIC_METER_TYPE:  
						$d13 = $dataArr[$i];
						//get CRC digits
						$crc = substr($d13, strlen($d13)-2, strlen($d13)); 
					break;
					case  EXT_TEMP_TYPE:  
						$d14 = $dataArr[$i];
						//get CRC digits
						$crc = substr($d14, strlen($d14)-2, strlen($d14)); 
						
						print_r($d14);
					break;
					case  EXT_RAP_TYPE:
						$d15 = $dataArr[$i];
						//get CRC digits
						$crc = substr($d15, strlen($d15)-2, strlen($d15));
					break;
					case  RTC_TYPE:
					break;
					
					default:
						echo strlen($dataArr[$i])."'";
						if(strlen($dataArr[$i])==36)
						{
							$d16 = $dataArr[$i];
							//113c4150503e56312e313454e1ad8378e663
							$len = strlen($d16);
							$d16 = substr($d16, 0, $len-2);
							//113c4150503e56312e313454e1ad8378e6
							$lc = strlen($d16);
							$mac = substr($c,$lc-12, $lc);
							echo $mac; die();

						}
					break;
				}
			}

		}
		



		function GUID() {
			$guid = strtoupper(bin2hex(openssl_random_pseudo_bytes(16)));
			return $guid;
		}

		function utf8_str_split(string $input, int $splitLength = 1)
		{
			$re = \sprintf('/\\G.{1,%d}+/us', $splitLength);
			\preg_match_all($re, $input, $m);
			return $m[0];
		}
	
	
		 function removeUnsedBytes($value)
		{
			$l = strlen($value);
			return substr($value,4,$l);
		}
	
		function countNumberOfHeaders($haystack, $needle)
		{
			$count = strlen($haystack) - strlen(str_replace(str_split($needle), '', $haystack));
			return $count;
		}
	
		function countNumberOfFooters($haystack, $needle)
		{
			$count = strlen($haystack) - strlen(str_replace(str_split($needle), '', $haystack));
			return $count;
		}
	
		function setUID($uuid)
		{
			$UID = $uuid;
		}
	
		 function  getUID()
		{
			return $UID;
		}
	
		function setLen($leng)
		{
			$len = strlen($leng);
		}
	
		function getLen()
		{
			return $len;
		}
	
		function removeFooter($raw)
		{
			return str_replace(FOOTER, "", $raw);
		}
	
		function removeHeader($raw)
		{
			return str_replace(HEADER, "", $raw);
		} 

	
		function remove_empty($array)
		{
			return array_filter($array, '_remove_empty_internal');
		}
  

		const DOOR_TYPE = 1;
		const WATER_TYPE = 2;
		const LIGHT_TYPE = 3;
		const TEMP_HUMIDITY_TYPE = 4;
		const TEMP_TYPE = 5;
		const G_SENSOR_TYPE = 6;
		const RAP_TYPE = 7;
		const GPIO_TYPE = 8;
		const RELAY_TYPE = 9;
		const VOLTAGE_TYPE = 10;
		const NOISE_TYPE = 11;
		const SMOK_TYPE = 12;
		const ELECTRIC_METER_TYPE = 13;
		const EXT_TEMP_TYPE = 14;
		const EXT_RAP_TYPE = 15;
		const RTC_TYPE = 16;

		const HEADER = "a1a2a3";
		const FOOTER = "a3a2a1";

		static $guid;
		static $UID;
		static $len;
		$conn;    

	
	// based on original work from the PHP Laravel framework
	if (!function_exists('str_contains')) {
		function str_contains($haystack, $needle) {
			return $needle !== '' && mb_strpos($haystack, $needle) !== false;
		}
	}
?>
