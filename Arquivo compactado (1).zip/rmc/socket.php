<?php
declare(strict_types=1);
ini_set("default_socket_timeout", 6000);
ini_set('allow_url_fopen',"on");
//---------------------------------------
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ERROR | E_PARSE);
require_once('Core/RMC.php');
require_once("database.php");
//---------------------------------------
use \Core\RMC;
//---------------------------------------
$conn = connect();
//---------------------------------------
$address = "192.168.1.51";
$port = 55502;
$loop= true;
//---------------------------------------
const NUMBER_OF_CONNECTIOS =2;
//---------------------------------------

echo " -------------------------------------------- ";
echo "Iniciando em ".$address." porta ".$port." <br>";
echo " -------------------------------------------- ";

try
{   
    $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
    socket_set_option($socket, SOL_SOCKET, SO_REUSEADDR, 1);
    socket_bind($socket, $address, $port);
    socket_listen($socket, NUMBER_OF_CONNECTIOS);
    $client  = socket_accept($socket);
    do
    { 
        if(false ===( $result =  socket_read($client, 2024, PHP_BINARY_READ)))
        {
            echo "error on read"; exit;
        }

        $buf = bin2hex(@$result);
        if(!$buf = trim($buf))
        {
            $loop = true;
            continue;
        }    
        parseData($buf);
    }
    while($loop = true);

}   
catch(\Exception $e)
{
    var_dump($e); exit;
}
finally
{
    //socket_close($socket);
    //unset($socket);
}


function parseData($raw)
{
    
    $UID =GUID(); // set o ID a ser utilizado no DB  
    define('UID', $UID, true);
   
    //-----------------------------
    $conn = connect();
    //-----------------------------
    $dateTime = 'NOW()';
    //-----------------------------
    $dataRaw = preg_replace('/'.Core\RMC::FOOTER.Core\RMC::HEADER.'/', Core\RMC::FOOTER.'@'.Core\RMC::HEADER , $raw); //adiciona o @ onde o footer for serguido do header

    $dataArr = explode("@", $dataRaw); //transforma os dados em array 
    /** Array
    * (
    *     [0] => a1a2a31a00113c4150503e56312e313454e1ad8378e663a3a2a1
    *     [1] => a1a2a31f001254e1ad8378e601ab0b00000200000000030000000096a3a2a1
    *     [2] => a1a2a3100002010001000000faa3a2a1
    *     [3] => a1a2a31f00030400e30c000001e30c000002e30c000003e30c0000cea3a2a1
    *     [4] => a1a2a35b000e1000000000000100000000020000000003000000000400000000050000000006000000000700000000080000000009000000000a000000000b000000000c000000000d000000000e000000000f00000000d7a3a2a1
    *     [5] => a1a2a383000f1800000000000100000000020000000003000000000400000000050000000006000000000700000000080000000009000000000a000000000b000000000c000000000d000000000e000000000f0000000010000000001100000000120000000013000000001400000000150000000016000000001700000000a4a3a2a1
    *     [6] => a1a2a329000d010000000000010000000002000000000300000000040000000005000000002ca3a2a1
    *     [7] => a1a2a31f000804000000000001000000000200000000030000000017a3a2a1
    *     [8] => a1a2a3150009020000000000010000000007a3a2a1
    *     [9] => a1a2a31a000a0300000000000100000000020000000010a3a2a1
    *     [10] => a1a2a31500040100fbbee24101c472044217a3a2a1
    *     [11] => a1a2a329000601001b07000001c70d00000205060000031b07000004c70d0000050506000027a3a2a1
    * ) */

    
    $macs = array_map(function($val) 
    {
        if(stripos($val,'63') && intval(strlen($val))==intval(52) )
        {
            return $val;
        }
      
    }, $dataArr);

    if(!empty($macs) & !empty($macs[0]))
    {
        $mac = $macs[0];
    
        //a1a2a31a00113c4150503e56312e313454e1ad8378e663a3a2a1
        $mac = str_replace('a1a2a3','',$mac);
        //1a00113c4150503e56312e313454e1ad8378e663a3a2a1
        $mac = str_replace('a3a2a1','',$mac);
        //1a00113c4150503e56312e313454e1ad8378e663
        $mac = substr($mac,0, strlen($mac)-2);
        //1a00113c4150503e56312e313454e1ad8378e6
        $mac = substr($mac,strlen($mac)-12, strlen($mac));

        if($mac!='' | $mac !=null)
        {
            define('MAC', $mac, true);
            saveRawDatasets($raw, $UID, $mac);
        }else saveRawDatasets($raw, $UID, null);
    }

    $result = preg_filter('/a1a2a3+/', '', array_values($dataArr));
    $result2 = preg_filter('/a3a2a1+/', '', array_values($result));
   
    $output = array_map(function($val) 
            {
                return substr($val, 4, strlen($val));
            }, $result2);

     $out = array_filter($output, function($var) 
        {       global $conn;
                global $UID;
                $UID = UID;
                $dateTime ='NOW()';
                $conn = connect();
                $t=  strval(hexdec(substr($var, 0 , 2))) ;
                //11 12 02 03 0e 0f 0d 08 09 0a 04 06 10
                //17  18  1  2  3  14  15  13  8  9  10  4  6  16 
                if($t == '1')
                {
                    $d1 = $var;
                    //get CRC digits
                    $crc = substr($d1, strlen($d1)-2, strlen($d1));
                    $d1 = str_replace($crc, "", $d1);  //remover o crc
                    
                    $dt =utf8_str_split($d1,2);
                    $vv = $dt[3].$dt[4].$dt[5].$dt[6]; //valor variavel não convertido
                    $stmt  = $conn -> prepare("INSERT INTO  parseddatasets (uid, tipo, tipo_size, tipo_qtde_params, datahora) VALUES ( ? , ? , ? , ? , ?  )");
                    $stmt->execute( [$UID, strval( '1'), strval($crc) , strval($dt[2]) , $dateTime ] );
                    unset($stmt);

                    $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                    $stmt->execute( [$UID, strval( '1' ), "'".$dt[2]."'" , "'".$vv."'" , $dateTime ] );
                    unset($stmt);
                    unset($d1); unset($crc); unset($dt); unset($vv); unset($arr);
                }
                if($t == '2')
                {
                    $d2 = $var;
                    //get CRC digits
                    $crc = substr($d2, strlen($d2)-2, strlen($d2)); 
                    $d2 = str_replace($crc, "", $d2);  //remover o crc
    
                    $dt  = utf8_str_split($d2, 2);
                    $vv = $dt[3].$dt[4].$dt[5].$dt[6]; //valor variavel não convertido
                    
                
                        $stmt  = $conn -> prepare("INSERT INTO  parseddatasets (uid, tipo, tipo_size, tipo_qtde_params, datahora) VALUES ( ? , ? , ? , ? , ?  )");
                        $stmt->execute( [$UID, strval( '2'), strval($crc) , strval($dt[2]) , $dateTime ] );
                        unset($stmt);
    
                        $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                        $stmt->execute( [$UID, '2' , "'".$dt[2]."'" , "'".$vv."'" , $dateTime ] );
                        unset($stmt);unset($arr);
                }
                if($t == '3')
                {
                    $d3 = $var;
                    //get CRC digits
                    $crc = substr($d3, strlen($d3)-2, strlen($d3));  

                    $d3 = trim(str_replace($crc, "", $d3));  //remover o crc   030400e30c000001e30c000002e30c000003e30c0000
                    $d3 = trim(substr($d3,2, strlen($d3))); //remover o typedef  0400e30c000001e30c000002e30c000003e30c0000

                    $cols =intval(substr($d3,0,2)) ;

                    $d3 = trim(substr($d3,2, strlen($d3))); // remove a quantidade de colunas 00e30c000001e30c000002e30c000003e30c0000

                    $arr = (utf8_str_split($d3,2));

                    $valor1 = null;
                    $valor2 = null;
                    $valor3 = null;
                    $valor4 = null;

                    $col1 = null;
                    $col2 = null;
                    $col3 = null;
                    $col4 = null;

                

                    $stmt  = $conn -> prepare("INSERT INTO  parseddatasets (uid, tipo, tipo_size, tipo_qtde_params, datahora) VALUES ( ? , ? , ? , ? , ?  )");
                    $stmt->execute( [$UID, strval( '3'), strval($crc) , strval($cols) , $dateTime ] );
                    unset($stmt);

                    for($i =0 ; $i< count($arr); $i++)
                    {                           
                        if($i==0)
                        {
                            $col1 = $arr[$i];
                            $valor1 = $arr[1].$arr[2].$arr[3].$arr[4];
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '3' , "'".$col1."'" , "'".$valor1."'" , $dateTime ] );
                            unset($stmt);
                            unset($col1); unset($valor1);

                        }
                        if($i+$cols=5)
                        {
                            $v = $i+$cols;  
                            $col2 = $arr[$v];
                            $valor2 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '3' , "'".$col2."'" , "'".$valor2."'" , $dateTime ] );
                            unset($col2); unset($valor2);unset($stmt);
                        }
                        if($i+$cols=10)
                        {
                            $v = $i+$cols; 
                            $col3 = $arr[$v];
                            $valor3 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '3' , "'".$col3."'" , "'".$valor3."'" , $dateTime ] );
                            unset($col3); unset($valor3); unset($stmt);
                        }
                        if($i+$cols=15)
                        {
                            $v = $i+$cols; 
                            $col4 = $arr[$v];
                            $valor4 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '3' , "'".$col4."'" , "'".$valor4."'" , $dateTime ] );
                            unset($col4); unset($valor4); unset($stmt);unset($arr);
                            break;
                        }     
                    }
                }
                if($t =='4')
                {
                    //040100ef1fd74101f9931842cb
                    $d4 = $var; 
                    $crc = substr($d4, strlen($d4)-2, strlen($d4));
                    $d4 = str_replace($crc, "", $d4);  //remover o crc
                    $d4 = trim(substr($d4 ,2, strlen($d4))); //remover o type
                    $arr = utf8_str_split($d4,2);

                    $stmt  = $conn -> prepare("INSERT INTO  parseddatasets (uid, tipo, tipo_size, tipo_qtde_params, datahora) VALUES ( ? , ? , ? , ? , ?  )");
                    $stmt->execute( [$UID, strval('4'), strval($crc) , strval($dt[1]) , $dateTime ] );
                    
                    /*(
                    *    [0] => 01
                    *    [1] => 00
                    *    [2] => a9
                    *    [3] => 06
                    *    [4] => d9
                    *    [5] => 41 //temp ?
                    *    [6] => 01
                    *    [7] => 92
                    *    [8] => dc
                    *    [9] => 21
                    *    [10] => 42
                    )*/
                    $temp = $arr[5];
                    $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                    $stmt->execute( [$UID, strval( '1' ), "'".$dt[1]."'" , "'".$temp." °C'" , $dateTime ] );
                    unset($stmt);
                    unset($d4); unset($crc); unset($temp); unset($arr);
                }
                if($t=='5')
                {

                }
                if($t=='6')
                {

                }
                if($t=='7')
                {

                }
                if($t=='8')
                {

                }
                if($t=='9' )
                {

                }
                if($t=='10')
                {

                }
                if($t=='11' | $t=='17') //hex=0b
                {
                    $d11 = $var;
                    //113c4150503e56312e313454e1ad8378e663
                    $crc = substr($d11, strlen($d11)-2, strlen($d11));
    
                    $d11 = trim(str_replace($crc, "", $d11));  //remover o crc   113c4150503e56312e313454e1ad8378e663
                    $d11 = trim(substr($d11,2, strlen($d11))); //remover o typedef 3c4150503e56312e313454e1ad8378e6
    
                    $cols =intval(substr($d11,0,2)) ; 
                    $arr = (utf8_str_split($d11,2));
                    
                    $col1 =null;
                    $col2 =null;
                    $col3 =null;
    
                    $valor1 = null;
                    $valor2 = null;
                    $valor3 = null;
                    $count = 0;
                    $stmt  = $conn -> prepare("INSERT INTO  parseddatasets (uid, tipo, tipo_size, tipo_qtde_params, datahora) VALUES ( ? , ? , ? , ? , ?  )");
                    $stmt->execute( [$UID, strval( '11'), strval($crc) , strval($cols) , $dateTime ] );
    
                    for($i= 0; $i< sizeof($arr); $i++)
                    {
                        if(intval($i)==intval(1))
                        {
                            $col1 =$arr[$i];
                            $valor1 = $arr[$col1].$arr[1+$col1].$arr[2+$col1].$arr[3+$col1]; 
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '11' , $col1 , $valor1, $dateTime ] );
                            unset($stmt);
                            unset($col1); unset($valor1);
                        }
                        if(intval($i+$cols)==intval(5))
                        {
                            $v = $i+$cols;  
                            $col2 = $arr[$v];
                            $valor2 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '11' , "'".$col2."'" , "'".$valor2."'" , $dateTime ] );
                            unset($col2); unset($valor2);unset($stmt);
                        }
                        if(intval($i+$cols)==intval(10))
                        {
                            $v = $i+$cols; 
                            $col3 = $arr[$v];
                            $valor3 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '11' , "'".$col3."'" , "'".$valor3."'" , $dateTime ] );
                            unset($col3); unset($valor3); unset($stmt);
                            break;  
                        }
                                                     
                    }
                }
                if($t=='12' | $t=='18')//hex0c
                {
                    $d12 = $var;
                    //get CRC digits
                    $crc = substr($d12, strlen($d12)-2, strlen($d12)); 
                    //1254e1ad8378e601ab0b00000200000000030000000096
                    $d12 = trim(str_replace($crc, "", $d12));
                    $d12 = trim(substr($d12 ,2, strlen($d12))); //remover o typedef   
                    //54e1ad8378e601ab0b000002000000000300000000
                    $cols =intval(substr($d12,1,2)) ;
    
                    $arr = (utf8_str_split($d12,2));  
    
                    $valor1 = null;
                    $valor2 = null;
                    $valor3 = null;
                    $valor4 = null;
    
                    $col1 = null;
                    $col2 = null;
                    $col3 = null;
                    $col4 = null;
    
                    $count = 0;
    
                    $stmt  = $conn -> prepare("INSERT INTO  parseddatasets (uid, tipo, tipo_size, tipo_qtde_params, datahora) VALUES ( ? , ? , ? , ? , ?  )");
                    //$stmt->execute( [$UID, strval( '12'), strval($cols) , strval($crc) , $dateTime ] ) or die('stmt error line 250');
                    $stmt->execute( [$UID, strval( '12'), strval($crc) , strval($cols) , $dateTime ] );
                    unset($stmt);
    
                    for($i =0 ; $i< count($arr); $i++)
                    {
                        if($i==1)
                        {
                            $col1 = $arr[$i];
                            $valor1 = $arr[1+$col1].$arr[2+$col1].$arr[3+$col1].$arr[4+$col1];
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '12' , "'".$col1."'" , "'".$valor1."'" , $dateTime ] );
                            unset($stmt);
                            unset($col1); unset($valor1);
                        }	
                        if($i+$cols=6)
                        {
                            $v = $i+$cols;  
                            $col2 = $arr[$v];
                            $valor2 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '12' , "'".$col2."'" , "'".$valor2."'" , $dateTime ] );
                            unset($col2); unset($valor2);unset($stmt);
                        }
                        if($i+$cols=11)
                        {
                            $v = $i+$cols; 
                            $col3 = $arr[$v];
                            $valor3 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '12' , "'".$col3."'" , "'".$valor3."'" , $dateTime ] );
                            unset($col3); unset($valor3); unset($stmt);
                        }
                        if($i+$cols=16)
                        {
                            $v = $i+$cols; 
                            $col4 = $arr[$v];
                            $valor4 = $arr[1+$v].$arr[2+$v].$arr[3+$v].$arr[4+$v];
                            $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                            $stmt->execute( [$UID,  '12' , "'".$col4."'" , "'".$valor4."'" , $dateTime ] );
                            unset($col4); unset($valor4); unset($stmt);
                            break;
                        } 
                    }
                                
                }
                if($t=='0a' | $t=='16')//dec=10
                {
                    $d16 = $var; 
                    //1001002300000001100000000226000000030400000004150000000544000000063500000025
                    $crc = substr($d16, strlen($d16)-2, strlen($d16));
                    $d16 = str_replace($crc, "", $d16);  //remover o crc
                    $d16 = trim(substr($d16 ,2, strlen($d16))); //remover o type
                    $arr = utf8_str_split($d16,2);

                    $cols = $arr[0];

                    $stmt  = $conn -> prepare("INSERT INTO  parseddatasets (uid, tipo, tipo_size, tipo_qtde_params, datahora) VALUES ( ? , ? , ? , ? , ?  )");
                    $stmt->execute( [$UID, strval( '16'), strval($crc) , strval($cols) , $dateTime ] );
                    unset($stmt);

                    $data =$arr[12].'/'.$arr[7].'/'. $arr[2].' - '.$arr[22].":".$arr[27].":".$arr[32]." GMT:".$arr[16];
                    //echo"->16->"; var_dump($arr);
                    $valor1 = $arr[1+$col1].$arr[2+$col1].$arr[3+$col1].$arr[4+$col1];
                    $stmt = $conn ->prepare("INSERT INTO parseddatasets_x_types (uid, tipo, param_id, param_data, datahora) VALUES ( ? , ? , ? , ? , ? )");
                    $stmt->execute( [$UID,  '16' , "'".$cols."'" , "'".$data."'" , $dateTime ] );
                    unset($stmt);
                    unset($col1); unset($valor1);unset($arr);
                }
                if($t=='0d' | $t=='13')//dec=13
                {

                }
                if($t=='0e' | $t=='14')//dec=14
                {

                }
                if($t=='0f' | $t=='15')//dec=15
                {

                }             
                return $val;
    
        }
    );

    if(!empty($out))
    {
        var_dump($out);
    }
    //
    unset($untestedata);
    unset($dataArr);
    unset($result); 
    
}




function saveRawDatasets($dataRaw, $UID, $mac)
{
    global $conn;
    $dateTime = 'NOW()';
    $SQL ="INSERT INTO predatasets (uid, raw_data, raw_bytes,datetime, rmc_ip, rmc_mac) VALUES ( ? , ? , ? , ? , ? , ? )";
    $stmt = $conn -> prepare($SQL);
    $stmt->execute( [$UID, strval( $dataRaw), strval($dataRaw)  , $dateTime  , 'not present', $mac] ) or die('saveRawDatasets');
    unset($stmt);
}


function GUID() {
    $guid = strtoupper(bin2hex(openssl_random_pseudo_bytes(16)));
    return $guid;
}

function utf8_str_split(string $input, int $splitLength = 1)
{
    $re = \sprintf('/\\G.{1,%d}+/us', $splitLength);
    \preg_match_all($re, $input, $m);
    return $m[0];
}

function countNumberOfHeaders($haystack, $needle)
{
    $count = strlen($haystack) - strlen(str_replace(str_split($needle), '', $haystack));
    return $count;
}

function countNumberOfFooters($haystack, $needle)
{
    $count = strlen($haystack) - strlen(str_replace(str_split($needle), '', $haystack));
    return $count;
}

function setUID($uuid)
{
    $UID = $uuid;
}

 function  getUID()
{
    return $UID;
}

function setLen($leng)
{
    $len = strlen($leng);
}

function getLen()
{
    return $len;
}

function removeFooter($raw)
{
   if($raw!=null)
   {
        return ;
   }
}

function removeHeader($raw)
{
    if($raw!=null)
    {
        return str_replace(RMC::HEADER, "", $raw);
    }
} 


function remove_empty($array)
{
    return array_filter($array, '_remove_empty_internal');
}

    static $dta =[];
    static $guid;
    static $UID;
    static $len;
    static $mac;
    $conn;    

    const DOOR_TYPE = 1;
    const WATER_TYPE = 2;
    const LIGHT_TYPE = 3;
    const TEMP_HUMIDITY_TYPE = 4;
    const TEMP_TYPE = 5;
    const G_SENSOR_TYPE = 6;
    const RAP_TYPE = 7;
    const GPIO_TYPE = 8;
    const RELAY_TYPE = 9;
    const VOLTAGE_TYPE = 10;
    const NOISE_TYPE = 11;
    const SMOK_TYPE = 12;
    const ELECTRIC_METER_TYPE = 13;
    const EXT_TEMP_TYPE = 14;
    const EXT_RAP_TYPE = 15;
    const RTC_TYPE = 16;

    // based on original work from the PHP Laravel framework
    if (!function_exists('str_contains')) {
        function str_contains($haystack, $needle) {
            return $needle !== '' && mb_strpos($haystack, $needle) !== false;
        }
    }


?>
